import discord
from discord.ext import commands

class PokedexCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command()
    async def info(self, ctx, pokemon_name: str):
        """Comando para obtener la información de un Pokémon."""
        # Aquí puedes agregar la lógica para obtener la información del Pokémon.
        # Para la demostración, usaré una respuesta fija.
        pokemon_info = f"Información de {pokemon_name}:\nEs un Pokémon muy popular. ¡Tiene muchas habilidades!"

        embed = discord.Embed(
            title=f"Pokédex: {pokemon_name}",
            description=pokemon_info,
            color=discord.Color.blue()
        )
        # Añadir una imagen o foto del Pokémon (usa una URL)
        embed.set_thumbnail(url="https://example.com/pokemon_image.png")

        await ctx.send(embed=embed)

def setup(bot):
    bot.add_cog(PokedexCog(bot))
