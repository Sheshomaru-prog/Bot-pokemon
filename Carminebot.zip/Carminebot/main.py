import os
import discord
from discord.ext import commands
from discord.ui import View, Button
import requests
import random
from dotenv import load_dotenv

# Cargar las variables de entorno
load_dotenv()

# Obtener el token de Discord desde las variables de entorno
DISCORD_TOKEN = os.getenv('DISCORD_TOKEN')

# Crear un bot de Discord
intents = discord.Intents.default()
intents.message_content = True  # Necesario para leer el contenido de los mensajes

bot = commands.Bot(command_prefix="!!", intents=intents)

# 📌 Diccionarios de traducción de tipos, habilidades y movimientos
TRADUCCION_TIPOS = {
    "normal": "Normal", "fire": "Fuego", "water": "Agua", "electric": "Eléctrico", "grass": "Planta",
    "ice": "Hielo", "fighting": "Lucha", "poison": "Veneno", "ground": "Tierra", "flying": "Volador",
    "psychic": "Psíquico", "bug": "Bicho", "rock": "Roca", "ghost": "Fantasma", "dragon": "Dragón",
    "dark": "Siniestro", "steel": "Acero", "fairy": "Hada"
}

# 📌 Probabilidades base de captura por rareza
CAPTURE_RATES = {
    "comun": 7,
    "poco_comun": 14,
    "raro": 21,
    "especial": 28,
    "ultra_raro": 35,
    "mitico": 70,
    "legendario": 70
}

# Evento cuando el bot está listo
@bot.event
async def on_ready():
    print(f'Conectado como {bot.user}')

# 📌 Comando para obtener información de un Pokémon
@bot.command()
async def info(ctx, pokemon_name: str):
    pokemon_name = pokemon_name.lower()
    response = requests.get(f'https://pokeapi.co/api/v2/pokemon/{pokemon_name}')

    if response.status_code != 200:
        await ctx.send(f"No pude encontrar información sobre **{pokemon_name}**. Asegúrate de escribir el nombre correctamente.")
        return

    data = response.json()
    name = data['name'].capitalize()
    height = data['height'] / 10  
    weight = data['weight'] / 10  
    types = [TRADUCCION_TIPOS.get(t['type']['name'], t['type']['name'].capitalize()) for t in data['types']]
    image_url = data['sprites']['front_default']

    species_response = requests.get(data['species']['url'])
    species_data = species_response.json()
    description = next((entry['flavor_text'].replace("\n", " ") for entry in species_data['flavor_text_entries'] if entry['language']['name'] == 'es'), "No se encontró descripción en español.")

    embed = discord.Embed(title=f"Información de {name}", description=f"¡Aquí tienes los detalles de **{name}**!", color=discord.Color.blue())
    embed.add_field(name="Tipos", value=", ".join(types), inline=False)
    embed.add_field(name="Altura", value=f"{height} m", inline=False)
    embed.add_field(name="Peso", value=f"{weight} kg", inline=False)
    embed.add_field(name="Descripción", value=description, inline=False)
    embed.set_thumbnail(url=image_url)

    view = View()
    view.add_item(Button(label="Habilidades", style=discord.ButtonStyle.primary, custom_id=f"habilidades_{pokemon_name}"))
    view.add_item(Button(label="Movimientos", style=discord.ButtonStyle.primary, custom_id=f"movimientos_{pokemon_name}"))

    await ctx.send(embed=embed, view=view)

@bot.event
async def on_interaction(interaction: discord.Interaction):
    custom_id = interaction.data["custom_id"]
    if custom_id.startswith("habilidades_"):
        pokemon_name = custom_id.split("_")[1]
        await mostrar_habilidades(interaction, pokemon_name)
    elif custom_id.startswith("movimientos_"):
        pokemon_name = custom_id.split("_")[1]
        await mostrar_movimientos(interaction, pokemon_name)

async def mostrar_habilidades(interaction, pokemon_name):
    response = requests.get(f'https://pokeapi.co/api/v2/pokemon/{pokemon_name}')
    data = response.json()
    habilidades = []

    for habilidad in data['abilities']:
        habilidad_name = habilidad['ability']['name']
        habilidad_url = habilidad['ability']['url']
        habilidad_data = requests.get(habilidad_url).json()
        habilidad_es = next((entry['name'] for entry in habilidad_data['names'] if entry['language']['name'] == 'es'), habilidad_name.capitalize())
        habilidades.append(habilidad_es)

    embed = discord.Embed(title=f"Habilidades de {pokemon_name.capitalize()}", color=discord.Color.green())
    embed.add_field(name="Habilidades", value=", ".join(habilidades), inline=False)
    await interaction.response.edit_message(embed=embed, view=None)

async def mostrar_movimientos(interaction, pokemon_name):
    response = requests.get(f'https://pokeapi.co/api/v2/pokemon/{pokemon_name}')
    data = response.json()
    movimientos = []

    for move in data['moves'][:10]:
        move_name = move['move']['name']
        move_url = move['move']['url']
        move_data = requests.get(move_url).json()
        move_es = next((entry['name'] for entry in move_data['names'] if entry['language']['name'] == 'es'), move_name.capitalize())
        movimientos.append(move_es)

    embed = discord.Embed(title=f"Movimientos de {pokemon_name.capitalize()}", color=discord.Color.purple())
    embed.add_field(name="Movimientos", value=", ".join(movimientos), inline=False)
    await interaction.response.edit_message(embed=embed, view=None)

# 📌 Comando de captura
@bot.command()
async def Captura(ctx, rareza: str, modificador: str = "+0"):
    rareza = rareza.lower()

    if rareza not in CAPTURE_RATES:
        await ctx.send("Rareza no válida. Usa: común, poco_común, raro, especial, ultra_raro, mítico o legendario.")
        return

    if not modificador.startswith("+") or not modificador[1:].isdigit():
        await ctx.send("Formato incorrecto. Usa: !!Captura [Rareza] [+Número] (ejemplo: !!Captura comun +5)")
        return

    modificador_valor = min(10, max(0, int(modificador[1:])))
    probabilidad_final = max(1, CAPTURE_RATES[rareza] - modificador_valor)
    resultado = random.randint(1, probabilidad_final) == 1

    imagen_pokebola = "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT6bI-6vpAnjHrySrl4zGH_xK0qI3OY1d_FLA&s"

    if resultado:
        mensaje = f"🎉 **¡Captura exitosa!** 🎉\n¡Has atrapado al Pokémon!"
        color = discord.Color.green()
    else:
        mensaje = f"❌ **Captura fallida** ❌\nEl Pokémon se escapó..."
        color = discord.Color.red()

    embed = discord.Embed(description=mensaje, color=color)
    embed.set_thumbnail(url=imagen_pokebola)

    await ctx.send(embed=embed)

# 📌 Comando de desafío a un gimnasio
@bot.command()
async def desafiar(ctx, gimnasio: str):
    gimnasios_validos = [
        "volador", "lucha", "acero", "dragon", "electrico", "fuego", "normal", 
        "agua", "planta", "fantasma", "psiquico", "siniestro", 
        "primera prueba de alola", "segunda prueba de alola", 
        "tercera prueba de alola", "ultima prueba de alola"
    ]

    gimnasio = gimnasio.lower()

    if gimnasio not in gimnasios_validos:
        await ctx.send("❌ **Ese gimnasio no existe.** Usa uno de los siguientes: " + ", ".join(gimnasios_validos))
        return

    mensaje = f"⚔️ **¡Desafío al gimnasio {gimnasio.capitalize()}!** ⚔️\n" \
              f"{ctx.author.mention} ha retado al gimnasio **{gimnasio.capitalize()}**.\n" \
              f"<@&1352318575893024808> ¡Defiendan su honor y su gimnasio! 🔥🏆"

    await ctx.send(mensaje)

bot.run(DISCORD_TOKEN)


